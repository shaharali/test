  <h3>Apply for Testimonial</h3>
  <p>This is an assignment of PGD-20 of Course PGD-107</p>

<form action="action.php" method="POST">
  <table class="table table-borderless" style="width: 1200px">
    <thead>
      <tr>
        <th style="width: 300px">DESCRIPTION</th>
        <th  style="width: 100px"></th>
        <th  style="width: 800px">INPUT</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Email</td>
        <td>:</td>
        <td>
          <input type="text" name="email" id="email" placeholder="email">
        </td>
      </tr>
       <tr>
        <td>Password</td>
        <td>:</td>
        <td>
          <input type="password" name="password" id="password" placeholder="password">
        </td>
      </tr>
       <tr>
        <td>Name</td>
        <td>:</td>
        <td>
          <input type="text" name="name" id="name" placeholder="name">
        </td>
      </tr>
       <tr>
        <td>Father</td>
        <td>:</td>
        <td>
          <input type="text" name="father" id="father" placeholder="father">
        </td>      
      </tr>  
       <tr>
        <td>Mother</td>
        <td>:</td>
        <td>
          <input type="text" name="mother" id="mother" placeholder="mother">
        </td>
      </tr>  
       <tr>
        <td>Address</td>
        <td>:</td>
        <td>
          <input type="text" name="address" id="address" placeholder="address">
        </td>
      </tr> 
       <tr>
        <td>Mobile</td>
        <td>:</td>
        <td>
          <input type="text" name="examination" id="examination" placeholder="examination">
        </td>
      </tr>
       <tr>
        <td>Roll</td>
        <td>:</td>
        <td>
          <input type="text" name="roll" id="roll" placeholder="roll">
        </td>
      </tr>
       <tr>
        <td>Year</td>
        <td>:</td>
        <td>
          <input type="text" name="year" id="year" placeholder="year">
        </td>
      </tr>
       <tr>
        <td>GPA</td>
        <td>:</td>
        <td>
          <input type="text" name="gpa" id="gpa" placeholder="gpa">
        </td>
      </tr>
       <tr>
        <td>Payment Amount</td>
        <td>:</td>
        <td>
          <input type="text" name="payment" id="payment" placeholder="payment">
        </td>
      </tr>
       <tr>
        <td></td>
        <td></td>
        <td>
          <input type="submit" name="apply" id="apply" value="Apply">
        </td>
      </tr>
    </tbody>
  </table>
  
</form>
